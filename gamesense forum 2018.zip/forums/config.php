<?php

$db_type = 'mysqli';
$db_host = 'localhost';
$db_name = ''; // base
$db_username = ''; //login bd
$db_password = ''; //pass db
$db_prefix = '';
$p_connect = false;

$cookie_name = 'gamesense_cookie_5123cb'; //cookie change  plz
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'c85432f3d4f954ad'; // try too

define('PUN', 1);
