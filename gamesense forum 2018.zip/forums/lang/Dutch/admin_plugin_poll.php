<?php

$lang_admin_plugin_poll = array(

'Plugin title'	=>	'Poll:',
'Explanation 1'	=>	'Deze plugin dient om aanpassingen te maken aan de polls op het forum.',
'Explanation 2'	=>	'Je kan polls in of uitschakelen, het aantal vragen en verschillende antwoorden en anderen parameters aanpassen.',
'Form title'	=>	'Opties',
'Show text button'	=>	'Opslaan',
'Plugin redirect'	=>	'Aanpassingen opgeslagen. Doorverwijzen â€¦',
'Legend1'	=>	'Algemeen',
'Legend3'	=>	'Uitgebreide opties',
'Q1' => 'Vink aan om polls te actieveren.',
'Q2' => 'Maximum aantal vragen in een poll. <strong>Het wordt aangeraden om dit van de eerste keer juist in te stellen!</strong>',
'Q3' => 'Maximum aantal antwoorden per vraag. <strong>Het wordt aangeraden om dit van de eerste keer juist in te stellen!</strong>',
'Q4' => 'Tijd na het aanmaken van een poll om wijzigingen aan te brengen (in minuten). <strong>0 - geen restrictie.</strong>',
'Q5' => 'Beperk de resultaten tot dit aantal weer te geven antwoorden<strong>Wordt samengevoegd in de poll.</strong>',
'Q6' => 'Gasten mogen resultaten zien.',

);
