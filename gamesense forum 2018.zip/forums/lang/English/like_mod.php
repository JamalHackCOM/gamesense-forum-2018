<?php

// Language definitions used by Like mod

$lang_like_mod = array(
	'Like'						=>	'Like',
	'Unlike'					=>	'Unlike',
	'Like this post'			=>	'Liked by:',
	'Like this post multiple'	=>	'Liked by:',
	'Like registered'			=>	'Like registered',
	'Self like'					=>	'You are not allowed to like your own posts.',
);