<?php

$lang_admin_plugin_poll = array(

'Plugin title'	=>	'Poll',
'Explanation 1'	=>	'Plugin wzbogaca forum o możliwość dodawania do tematów ankiet.',
'Explanation 2'	=>	'Możesz dodawać i zdejmować ankiety z forum, regulować liczbę, formę odpowiedzi oraz wiele innych.',
'Form title'	=>	'Opcje',
'Show text button'	=>	'Zapisz zmiany',
'Plugin redirect'	=>	'Zapisano zmiany. Przekierowuję…',
'Legend1'	=>	'Opcje globalne',
'Legend3'	=>	'Opcje dodatkowe',
'Q1' => 'Włącz obsługę ankiet.',
'Q2' => 'Maksymalna liczba pytań na jedną ankietę. <strong>Zaleca się, by ustalić tylko raz!</strong>',
'Q3' => 'Maksymalna liczba odpowiedzi na jedno pytanie. <strong>Zaleca się, by ustalić tylko raz!</strong>',
'Q4' => 'Czas edycji ankiety (w minutach). <strong>0 - bez restrykcji czasowej.</strong>',
'Q5' => 'Wymagana liczba głosów, by pokazać wyniki ankiety.',
'Q6' => 'Goście mogą oglądać wyniki głosowania.',

);
