<?php

$lang_colorize_groups = array(
'Group color'			=> 'Couleur du groupe',
'Group color help'		=> 'Définition de la couleur du groupe. Laissez vide pour utiliser la couleur par défaut.',
'Inalid color message'	=> 'La couleur que vous avez entrée est invalide.',

'Legend'				=> 'Légende',
);
