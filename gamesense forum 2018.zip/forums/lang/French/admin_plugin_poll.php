<?php

$lang_admin_plugin_poll = array(

'Plugin title'	=>	'Sondage',
'Explanation 1'	=>	'Le plugin permet d\'adapter les sondages aux besoins de vos forums.',
'Explanation 2'	=>	'Vous pouvez activer/désactiver les sondages sur vos forums, régler le nombre de questions, des réponses et d\'autres paramètres.',
'Form title'	=>	'Options',
'Show text button'	=>	'Enregistrer les modifications',
'Plugin redirect'	=>	'Options mis à jour. Redirection …',
'Legend1'	=>	'Options générales',
'Legend3'	=>	'Options supplémentaires',
'Q1' => 'Utiliser les sondages sur ces forums.',
'Q2' => 'Nombre maximal de questions dans un sondage. <strong>Il est recommandé de définir un nombre une fois !</strong>',
'Q3' => 'Nombre de réponses maximal dans une question. <strong>Il est recommandé de définir un nombre une fois !</strong>',
'Q4' => 'Temps d\'édition d\'un sondage (en minutes). <strong>0 - sans limite de temps.</strong>',
'Q5' => 'Nombre de votes à partir duquel seront dévoilés les résultats du sondage (masqués tant que ce nombre n\'est pas atteint). <strong>Résultats divulgués.</strong>',
'Q6' => 'Les invités voient les résultats du vote.',

);
