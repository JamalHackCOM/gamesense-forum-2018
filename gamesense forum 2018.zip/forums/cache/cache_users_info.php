<?php

define('PUN_USERS_INFO_LOADED', 1);

$stats = array (
  'total_users' => '2',
  'last_user' => 
  array (
    'id' => '2',
    'username' => 'w3rn3r',
    'group_id' => '1',
  ),
);

?>