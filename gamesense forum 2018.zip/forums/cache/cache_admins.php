<?php

define('PUN_ADMINS_LOADED', 1);

$pun_admins = array (
  0 => '2',
  1 => '3',
);

?>