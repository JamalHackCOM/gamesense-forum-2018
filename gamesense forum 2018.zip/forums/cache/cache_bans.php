<?php

define('PUN_BANS_LOADED', 1);

$pun_bans = array (
);

?>